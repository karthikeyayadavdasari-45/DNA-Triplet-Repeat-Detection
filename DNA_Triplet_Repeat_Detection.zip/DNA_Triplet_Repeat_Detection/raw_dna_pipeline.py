
from pathlib import Path
from collections import Counter
import csv

# Output folder
PROJECT_DIR = Path(__file__).resolve().parent
RESULTS_DIR = PROJECT_DIR / "results"
RESULTS_DIR.mkdir(exist_ok=True)


def validate_sequence(sequence):
    """Keep valid DNA bases and reject invalid characters."""
    sequence = "".join(sequence.split()).upper()

    if not sequence:
        raise ValueError("DNA sequence cannot be empty.")

    invalid = sorted(set(sequence) - set("ATGC"))

    if invalid:
        raise ValueError(
            f"Invalid DNA characters found: {invalid}. "
            "Use only A, T, G and C."
        )

    return sequence


def analyze_sequence(sequence):
    """Analyze DNA composition and consecutive triplet repeats."""
    length = len(sequence)

    # Stage 3: DNA composition
    base_counts = Counter(sequence)
    gc_count = base_counts["G"] + base_counts["C"]
    gc_content = (gc_count / length) * 100

    # Stage 4: Extract complete triplets in reading frame 0
    complete_length = (length // 3) * 3
    triplets = [
        sequence[i:i + 3]
        for i in range(0, complete_length, 3)
    ]

    leftover_bases = length % 3

    # Count all triplets
    triplet_frequencies = Counter(triplets)

    # Stages 5 and 6: Find consecutive identical triplets
    repeat_runs = []
    i = 0

    while i < len(triplets):
        triplet = triplets[i]
        start_index = i
        count = 1

        while (
            i + 1 < len(triplets)
            and triplets[i + 1] == triplet
        ):
            count += 1
            i += 1

        if count >= 2:
            repeat_runs.append({
                "Triplet": triplet,
                "Repeat_Count": count,
                "Start_Base_1Based": start_index * 3 + 1,
                "End_Base_1Based": (start_index + count) * 3,
                "Repeated_Sequence": triplet * count,
            })

        i += 1

    return {
        "Length": length,
        "Base_Counts": base_counts,
        "GC_Content": gc_content,
        "Triplets": triplets,
        "Triplet_Frequencies": triplet_frequencies,
        "Repeat_Runs": repeat_runs,
        "Leftover_Bases": leftover_bases,
    }


def save_results(sequence, results):
    """Save the repeat detections and sequence summary."""
    repeat_file = RESULTS_DIR / "raw_triplet_repeat_results.csv"
    summary_file = RESULTS_DIR / "raw_dna_summary.txt"

    # Save detected repeat runs
    columns = [
        "Triplet",
        "Repeat_Count",
        "Start_Base_1Based",
        "End_Base_1Based",
        "Repeated_Sequence",
    ]

    with repeat_file.open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        writer.writerows(results["Repeat_Runs"])

    # Save summary
    with summary_file.open("w", encoding="utf-8") as file:
        file.write("DNA TRIPLET REPEAT ANALYSIS\n")
        file.write("=" * 35 + "\n")
        file.write(f"DNA sequence: {sequence}\n")
        file.write(f"Sequence length: {results['Length']}\n")

        file.write("\nNucleotide composition:\n")
        for base in "ATGC":
            count = results["Base_Counts"][base]
            percentage = count / results["Length"] * 100
            file.write(
                f"{base}: {count} ({percentage:.2f}%)\n"
            )

        file.write(
            f"\nGC content: {results['GC_Content']:.2f}%\n"
        )
        file.write(
            f"Complete triplets: {len(results['Triplets'])}\n"
        )
        file.write(
            f"Leftover bases: {results['Leftover_Bases']}\n"
        )

        file.write("\nTriplet frequencies:\n")
        for triplet, count in sorted(
            results["Triplet_Frequencies"].items()
        ):
            file.write(f"{triplet}: {count}\n")

        file.write("\nConsecutive repeat runs:\n")
        if results["Repeat_Runs"]:
            for run in results["Repeat_Runs"]:
                file.write(
                    f"{run['Triplet']} repeated "
                    f"{run['Repeat_Count']} times; "
                    f"bases {run['Start_Base_1Based']}-"
                    f"{run['End_Base_1Based']}\n"
                )
        else:
            file.write("No consecutive identical triplets found.\n")

    return repeat_file, summary_file


def main():
    print("=" * 48)
    print("DNA TRIPLET REPEAT DETECTION PIPELINE")
    print("=" * 48)

    print("\nEnter a DNA sequence using A, T, G and C.")
    print("Press Enter without typing to use the example sequence.")

    sequence_input = input("\nDNA sequence: ").strip()

    if not sequence_input:
        sequence_input = "ATGCAGCAGCAGCAGTTACGGCGG"
        print("Using the example sequence:", sequence_input)

    try:
        sequence = validate_sequence(sequence_input)
    except ValueError as error:
        print("\nINPUT ERROR:", error)
        return

    results = analyze_sequence(sequence)

    print("\n1. SEQUENCE VALIDATION")
    print("Valid DNA sequence: Yes")

    print("\n2. DNA COMPOSITION")
    print("Sequence length:", results["Length"])

    for base in "ATGC":
        print(f"{base} count:", results["Base_Counts"][base])

    print(f"GC content: {results['GC_Content']:.2f}%")

    print("\n3. TRIPLET EXTRACTION")
    print("Complete triplets:", len(results["Triplets"]))
    print("Triplets:", " ".join(results["Triplets"]))

    print("\n4. TRIPLET FREQUENCIES")
    for triplet, count in sorted(
        results["Triplet_Frequencies"].items()
    ):
        print(f"{triplet}: {count}")

    print("\n5. CONSECUTIVE REPEAT DETECTION")
    if results["Repeat_Runs"]:
        for run in results["Repeat_Runs"]:
            print(
                f"{run['Triplet']} repeats "
                f"{run['Repeat_Count']} times "
                f"(bases {run['Start_Base_1Based']}-"
                f"{run['End_Base_1Based']})"
            )
    else:
        print("No consecutive identical triplets found.")

    if results["Leftover_Bases"]:
        print(
            "\nNote:",
            results["Leftover_Bases"],
            "base(s) at the end do not form a complete triplet."
        )

    repeat_file, summary_file = save_results(sequence, results)

    print("\n6. OUTPUT FILES")
    print("Repeat results:", repeat_file)
    print("Summary report:", summary_file)
    print("\nAnalysis completed successfully.")


if __name__ == "__main__":
    main()
