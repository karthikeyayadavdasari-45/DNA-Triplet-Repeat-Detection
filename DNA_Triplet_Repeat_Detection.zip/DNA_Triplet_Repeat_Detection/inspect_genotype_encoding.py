
import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"

for motif in ["CAG", "CGG", "GAA"]:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    print(f"\n{'=' * 55}")
    print(f"{motif}: GENOTYPE ENCODING")
    print("=" * 55)

    print("\nAll GT value counts:")
    print(df["GT"].value_counts(dropna=False).to_string())

    print("\nGT and allele-count combinations:")
    summary = (
        df.groupby(
            ["GT", "Allele1_Units", "Allele2_Units"],
            dropna=False
        )
        .size()
        .reset_index(name="Rows")
    )

    print(summary.head(20).to_string(index=False))

    print("\nExample rows for numeric GT values:")
    numeric_gt = df["GT"].str.strip().isin(["0", "1", "2"])

    columns = [
        "Sample_ID", "Call_ID", "GT",
        "Ref_Units", "Allele1_Units", "Allele2_Units"
    ]

    print(
        df.loc[numeric_gt, columns]
        .head(10)
        .to_string(index=False)
    )

print("\nInspection complete. No original files modified.")
