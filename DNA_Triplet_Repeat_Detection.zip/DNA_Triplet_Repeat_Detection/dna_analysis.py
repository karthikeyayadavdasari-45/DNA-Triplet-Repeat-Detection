"""Starter functions for DNA sequence analysis."""
from collections import Counter

DNA_BASES = set("ATGC")


def validate_dna_sequence(sequence: str) -> str:
    """Normalize and validate a DNA sequence containing only A, T, G, and C."""
    if not isinstance(sequence, str):
        raise TypeError("DNA sequence must be a string.")
    normalized = "".join(sequence.split()).upper()
    if not normalized:
        raise ValueError("DNA sequence cannot be empty.")
    invalid = sorted(set(normalized) - DNA_BASES)
    if invalid:
        raise ValueError(f"Invalid DNA character(s): {', '.join(invalid)}")
    return normalized


def analyze_dna_sequence(sequence: str) -> dict:
    """Compute base counts, GC content, and repeats in fixed-frame triplets."""
    dna = validate_dna_sequence(sequence)
    counts = Counter(dna)
    triplets = [dna[i:i + 3] for i in range(0, len(dna) - 2, 3)]
    repeats = []
    i = 0
    while i < len(triplets):
        run = 1
        while i + run < len(triplets) and triplets[i + run] == triplets[i]:
            run += 1
        if run > 1:
            repeats.append({
                "motif": triplets[i],
                "repeat_count": run,
                "start_triplet_index": i,
            })
        i += run
    n = len(dna)
    return {
        "sequence_length": n,
        "A_count": counts["A"],
        "T_count": counts["T"],
        "G_count": counts["G"],
        "C_count": counts["C"],
        "GC_content_percent": round((counts["G"] + counts["C"]) / n * 100, 4),
        "triplets": triplets,
        "consecutive_triplet_repeats": repeats,
        "unused_bases_at_end": n % 3,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(analyze_dna_sequence("ATGCAGCAGCAGCAGTTACGGCGG"), indent=2))
