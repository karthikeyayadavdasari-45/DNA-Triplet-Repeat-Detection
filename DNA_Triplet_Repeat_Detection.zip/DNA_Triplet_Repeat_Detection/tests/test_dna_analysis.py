import pytest
from dna_analysis import analyze_dna_sequence, validate_dna_sequence


def test_normalizes_lowercase_and_spaces():
    assert validate_dna_sequence(" atg cag ") == "ATGCAG"


def test_rejects_empty_sequence():
    with pytest.raises(ValueError):
        validate_dna_sequence("  ")


def test_rejects_invalid_characters():
    with pytest.raises(ValueError):
        validate_dna_sequence("ATGN")


def test_sample_statistics():
    result = analyze_dna_sequence("ATGCAGCAGCAGCAGTTACGGCGG")
    assert result["sequence_length"] == 24
    assert result["A_count"] == 6
    assert result["T_count"] == 3
    assert result["G_count"] == 9
    assert result["C_count"] == 6
    assert result["GC_content_percent"] == 62.5


def test_detects_fixed_frame_repeats():
    result = analyze_dna_sequence("ATGCAGCAGCAG")
    assert any(r["motif"] == "CAG" and r["repeat_count"] == 3
               for r in result["consecutive_triplet_repeats"])
