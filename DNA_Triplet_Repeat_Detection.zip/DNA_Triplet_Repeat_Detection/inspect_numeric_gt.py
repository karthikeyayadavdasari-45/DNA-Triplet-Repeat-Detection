
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "data"

columns = [
    "Sample_ID", "Call_ID", "Chr", "Start", "End",
    "GT", "Ref_Units", "Allele1_Units", "Allele2_Units"
]

for motif in ["CAG", "CGG", "GAA"]:
    file_path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"

    df = pd.read_csv(file_path, sep="\t", dtype=str)
    df["GT"] = df["GT"].str.strip()

    numeric_rows = df[df["GT"].isin(["0", "1", "2"])]

    print("\n" + "=" * 55)
    print(f"{motif} — NUMERIC GENOTYPE EXAMPLES")
    print("=" * 55)
    print("Number of numeric GT rows:", len(numeric_rows))

    if numeric_rows.empty:
        print("No numeric GT rows found.")
    else:
        print(numeric_rows[columns].head(10).to_string(index=False))

print("\nInspection completed. Original datasets were not modified.")
