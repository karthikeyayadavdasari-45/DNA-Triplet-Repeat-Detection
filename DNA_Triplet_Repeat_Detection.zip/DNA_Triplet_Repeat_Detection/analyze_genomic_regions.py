
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = Path("data")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

files = {
    "CAG": "CAG_Platinum_by_locus.csv",
    "CGG": "CGG_Platinum_by_locus.csv",
    "GAA": "GAA_Platinum_by_locus.csv",
}
frames = []

for motif, filename in files.items():
    path = DATA_DIR / filename

    df = pd.read_csv(path, sep="\t")

    # Check that the required column exists
    if "Region" not in df.columns:
        raise ValueError(f"'Region' column missing in {filename}")

    # Keep the recorded region categories
    regions = df[["Region"]].copy()
    regions["Motif"] = motif
    regions["Region"] = regions["Region"].fillna("Missing")

    frames.append(regions)

combined = pd.concat(frames, ignore_index=True)

# Count loci by motif and genomic region
counts = pd.crosstab(combined["Region"], combined["Motif"])

# Save counts
counts.to_csv(RESULTS_DIR / "genomic_region_counts.csv")

# Calculate percentages within each motif
percentages = counts.div(counts.sum(axis=0), axis=1) * 100
percentages.to_csv(RESULTS_DIR / "genomic_region_percentages.csv")

print("\nLOCUS COUNTS BY GENOMIC REGION")
print(counts.to_string())

print("\nPERCENTAGE WITHIN EACH MOTIF")
print(percentages.round(2).to_string())

# Plot percentage distribution
ax = percentages.plot(
    kind="bar",
    figsize=(11, 6)
)

ax.set_title("Genomic Region Distribution of DNA Repeat Motifs")
ax.set_xlabel("Genomic Region")
ax.set_ylabel("Loci within each motif (%)")
ax.tick_params(axis="x", rotation=45)

plt.legend(title="DNA Motif")
plt.tight_layout()

plt.savefig(
    RESULTS_DIR / "genomic_region_comparison.png",
    dpi=300
)

plt.show()

print("\nAnalysis completed.")
print("Results saved in the results folder.")
