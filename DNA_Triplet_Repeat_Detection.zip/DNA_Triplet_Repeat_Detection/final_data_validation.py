
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "data"
RESULTS_DIR = Path(__file__).resolve().parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

files = {
    "CAG": "Repeats_CAG_Platinum_filtered.csv",
    "CGG": "Repeats_CGG_Platinum_filtered.csv",
    "GAA": "Repeats_GAA_Platinum_filtered.csv",
}

reports = []

for motif, filename in files.items():
    path = DATA_DIR / filename

    print(f"\nChecking {motif}: {filename}")

    if not path.exists():
        print(f"FILE NOT FOUND: {path}")
        continue

    # Filtered files are tab-separated
    df = pd.read_csv(path, sep="\t")
    df.columns = df.columns.str.strip()

    print("Columns detected:", df.columns.tolist())

    repeat_cols = [
        "Ref_Units",
        "Allele1_Units",
        "Allele2_Units",
    ]

    required_cols = [
        "Call_ID", "Sample_ID", "Chr", "Start", "End",
        "GT", *repeat_cols
    ]

    missing = [c for c in required_cols if c not in df.columns]

    if missing:
        print("Missing required columns:", missing)
        continue

    # Check repeat-count values without changing source files
    for col in repeat_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    duplicate_keys = ["Sample_ID", "Chr", "Start", "End"]

    report = {
        "Motif": motif,
        "Rows": len(df),
        "Unique_Samples": df["Sample_ID"].nunique(),
        "Unique_Loci": df["Call_ID"].nunique(),
        "Duplicate_Sample_Locus_Rows": int(
            df.duplicated(subset=duplicate_keys).sum()
        ),
        "Missing_Values_Total": int(
            df[required_cols].isna().sum().sum()
        ),
        "Negative_Repeat_Counts": int(
            (df[repeat_cols] < 0).sum().sum()
        ),
        "Zero_Allele2_Counts": int(
            (df["Allele2_Units"] == 0).sum()
        ),
    }

    reports.append(report)
    print("Validation results:", report)

if reports:
    report_df = pd.DataFrame(reports)
    output_path = RESULTS_DIR / "final_data_validation.csv"
    report_df.to_csv(output_path, index=False)

    print("\nFINAL VALIDATION REPORT")
    print(report_df.to_string(index=False))
    print(f"\nSaved to: {output_path}")
else:
    print("\nNo files were validated. Check the column names above.")
