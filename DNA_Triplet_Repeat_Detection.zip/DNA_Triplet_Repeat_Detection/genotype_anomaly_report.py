
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parent / "data"
RESULTS_DIR = Path(__file__).resolve().parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

reports = []

for motif in ["CAG", "CGG", "GAA"]:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    df["GT"] = df["GT"].str.strip()
    df["Allele1_Units"] = pd.to_numeric(
        df["Allele1_Units"], errors="coerce"
    )
    df["Allele2_Units"] = pd.to_numeric(
        df["Allele2_Units"], errors="coerce"
    )

    numeric_gt = df["GT"].isin(["0", "1", "2"])
    zero_allele = df["Allele2_Units"].eq(0)

    print(f"\n{'=' * 45}")
    print(f"{motif} ANOMALY REPORT")
    print("=" * 45)
    print("Total rows:", len(df))
    print("Genotype values:")
    print(df["GT"].value_counts(dropna=False).to_string())
    print("Numeric GT rows:", int(numeric_gt.sum()))
    print("Rows with Allele2_Units = 0:", int(zero_allele.sum()))
    print(
        "Rows with numeric GT and zero second allele:",
        int((numeric_gt & zero_allele).sum())
    )

    reports.append({
        "Motif": motif,
        "Total_Rows": len(df),
        "Numeric_GT_Rows": int(numeric_gt.sum()),
        "Zero_Allele2_Rows": int(zero_allele.sum()),
        "Numeric_GT_And_Zero_Allele2_Rows": int(
            (numeric_gt & zero_allele).sum()
        )
    })

report = pd.DataFrame(reports)
report.to_csv(
    RESULTS_DIR / "genotype_anomaly_report.csv",
    index=False
)

print("\nReport saved to results/genotype_anomaly_report.csv")
print("Original datasets were not modified.")
