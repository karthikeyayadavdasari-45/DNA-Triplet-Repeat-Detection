
from pathlib import Path
import pandas as pd

data_dir = Path(__file__).resolve().parent / "data"

files = [
    "Repeats_CAG_Platinum_filtered.csv",
    "Repeats_CGG_Platinum_filtered.csv",
    "Repeats_GAA_Platinum_filtered.csv",
]

for filename in files:
    path = data_dir / filename

    df = pd.read_csv(
        path,
        sep="\t",
        dtype={"Call_ID": str},
        low_memory=False
    )

    ids = df["Call_ID"].dropna().str.strip()

    print("\n" + "=" * 45)
    print(filename)
    print("Rows:", len(df))
    print("Missing Call_ID:", df["Call_ID"].isna().sum())
    print("Unique Call_ID:", ids.nunique())
    print("Blank Call_ID:", ids.eq("").sum())
    print("First 5 IDs:", ids.head().tolist())

print("\nCall_ID type inspection completed.")
