from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(exist_ok=True)

MOTIFS = ["CAG", "CGG", "GAA"]


def load_dataset(motif):
    file_path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"

    if not file_path.exists():
        raise FileNotFoundError(f"Dataset not found: {file_path}")

    df = pd.read_csv(file_path, sep="\t")

    required = [
        "Call_ID", "Sample_ID", "Chr", "Start", "End",
        "GT", "Ref_Units", "Allele1_Units", "Allele2_Units"
    ]

    missing = set(required) - set(df.columns)
    if missing:
        raise ValueError(f"{motif}: missing columns {sorted(missing)}")

    return df


def analyze_dataset(motif, df):
    for col in ["Start", "End", "Ref_Units", "Allele1_Units", "Allele2_Units"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    allele_values = pd.concat(
        [df["Allele1_Units"], df["Allele2_Units"]],
        ignore_index=True
    ).dropna()

    summary = {
        "Motif": motif,
        "Rows": len(df),
        "Unique_Samples": df["Sample_ID"].nunique(),
        "Unique_Loci": df["Call_ID"].nunique(),
        "Missing_Allele1": int(df["Allele1_Units"].isna().sum()),
        "Missing_Allele2": int(df["Allele2_Units"].isna().sum()),
        "Mean_Allele_Repeat_Units": round(allele_values.mean(), 3),
        "Median_Allele_Repeat_Units": round(allele_values.median(), 3),
        "Minimum_Allele_Repeat_Units": int(allele_values.min()),
        "Maximum_Allele_Repeat_Units": int(allele_values.max()),
    }

    # Save the motif-level summary
    pd.DataFrame([summary]).to_csv(
        RESULTS_DIR / f"{motif}_summary.csv", index=False
    )

    # Save repeat-length distribution
    distribution = allele_values.value_counts().sort_index()
    distribution_df = distribution.rename_axis("Repeat_Units").reset_index(
        name="Count"
    )
    distribution_df.to_csv(
        RESULTS_DIR / f"{motif}_repeat_distribution.csv", index=False
    )

    # Plot repeat-length distribution
    plt.figure(figsize=(10, 5))
    distribution.plot(kind="bar")
    plt.title(f"{motif} Repeat-Unit Distribution")
    plt.xlabel("Repeat units per allele")
    plt.ylabel("Allele count")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / f"{motif}_distribution.png", dpi=150)
    plt.close()

    return summary


def main():
    summaries = []

    for motif in MOTIFS:
        df = load_dataset(motif)
        summaries.append(analyze_dataset(motif, df))
        print(f"Analyzed {motif}: {len(df)} records")

    pd.DataFrame(summaries).to_csv(
        RESULTS_DIR / "all_motifs_summary.csv", index=False
    )

    print("\nAnalysis completed.")
    print(f"Results saved in: {RESULTS_DIR}")


if __name__ == "__main__":
    main()