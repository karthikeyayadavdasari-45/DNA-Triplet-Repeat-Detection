
from pathlib import Path
import pandas as pd

data_dir = Path(__file__).resolve().parent / "data"

summary = pd.read_csv(
    data_dir / "GAA_Platinum_by_locus.csv",
    sep="\t",
    dtype={"Call_ID": str}
)

filtered = pd.read_csv(
    data_dir / "Repeats_GAA_Platinum_filtered.csv",
    sep="\t",
    dtype={"Call_ID": str}
)

summary_ids = set(summary["Call_ID"].dropna().str.strip())
filtered_ids = set(filtered["Call_ID"].dropna().str.strip())

only_filtered = sorted(filtered_ids - summary_ids)
only_summary = sorted(summary_ids - filtered_ids)

print("GAA LOCUS COMPARISON")
print("-" * 40)
print("Summary rows:", len(summary))
print("Summary unique IDs:", len(summary_ids))
print("Filtered rows:", len(filtered))
print("Filtered unique IDs:", len(filtered_ids))

print("\nIDs only in filtered dataset:", len(only_filtered))
print(only_filtered[:20])

print("\nIDs only in summary dataset:", len(only_summary))
print(only_summary[:20])
