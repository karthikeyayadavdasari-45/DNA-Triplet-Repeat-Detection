
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(exist_ok=True)

MOTIFS = ["CAG", "CGG", "GAA"]


def validate_dataset(motif):
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"

    if not path.exists():
        print(f"\n{motif}: FILE NOT FOUND: {path}")
        return None

    # Preserve identifiers as text and use the tab delimiter.
    df = pd.read_csv(path, sep="\t", dtype=str)

    required = [
        "Call_ID", "Sample_ID", "Chr", "Start", "End",
        "GT", "Ref_Units", "Allele1_Units", "Allele2_Units"
    ]

    missing_columns = sorted(set(required) - set(df.columns))

    print(f"\n{'=' * 55}")
    print(f"{motif} DATASET")
    print(f"{'=' * 55}")
    print(f"Rows: {len(df):,}")
    print(f"Columns: {len(df.columns)}")
    print(f"Column names: {df.columns.tolist()}")

    if missing_columns:
        print("Missing expected columns:", missing_columns)
        return None

    # Inspect sample IDs without assuming their meaning.
    sample_ids = df["Sample_ID"].dropna().str.strip()
    print(f"Unique non-empty Sample_ID values: {sample_ids.nunique():,}")
    print("First 15 Sample_ID values:")
    print(sample_ids.drop_duplicates().head(15).to_list())

    print("\nMost frequent Sample_ID values:")
    print(sample_ids.value_counts().head(10).to_string())

    # Check missing values.
    print("\nMissing values per column:")
    print(df[required].isna().sum().to_string())

    # Check duplicate call identifiers.
    print("\nDuplicate Call_ID rows:",
          int(df["Call_ID"].duplicated().sum()))

    # Inspect numeric repeat-unit columns.
    for col in ["Ref_Units", "Allele1_Units", "Allele2_Units"]:
        values = pd.to_numeric(df[col], errors="coerce")
        print(
            f"{col}: invalid/missing={values.isna().sum():,}, "
            f"minimum={values.min()}, maximum={values.max()}"
        )

    return {
        "Motif": motif,
        "Rows": len(df),
        "Columns": len(df.columns),
        "Unique_Sample_IDs": sample_ids.nunique(),
        "Duplicate_Call_ID_Rows": int(df["Call_ID"].duplicated().sum()),
        "Missing_Allele1": int(df["Allele1_Units"].isna().sum()),
        "Missing_Allele2": int(df["Allele2_Units"].isna().sum()),
    }


def main():
    reports = []

    for motif in MOTIFS:
        report = validate_dataset(motif)
        if report is not None:
            reports.append(report)

    if reports:
        output = RESULTS_DIR / "data_validation_report.csv"
        pd.DataFrame(reports).to_csv(output, index=False)
        print(f"\nValidation report saved to:\n{output}")


if __name__ == "__main__":
    main()
