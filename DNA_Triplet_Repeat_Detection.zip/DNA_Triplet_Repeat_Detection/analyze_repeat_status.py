
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = Path("data")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

files = {
    "CAG": "CAG_Platinum_by_locus.csv",
    "CGG": "CGG_Platinum_by_locus.csv",
    "GAA": "GAA_Platinum_by_locus.csv",
}

all_results = []

for motif, filename in files.items():
    df = pd.read_csv(DATA_DIR / filename, sep="\t")

    # Count each status exactly as recorded in the dataset
    counts = df["Status"].fillna("Missing").value_counts()

    for status, count in counts.items():
        all_results.append({
            "Motif": motif,
            "Status": status,
            "Locus_Count": int(count),
            "Percentage": round(count / len(df) * 100, 2),
        })

result = pd.DataFrame(all_results)

# Save the detailed table
result.to_csv(
    RESULTS_DIR / "repeat_status_analysis.csv",
    index=False
)

print("\nREPEAT STATUS ANALYSIS")
print(result.to_string(index=False))

# Create a grouped comparison chart
pivot = result.pivot(
    index="Motif",
    columns="Status",
    values="Locus_Count"
).fillna(0)

ax = pivot.plot(kind="bar", figsize=(9, 5))
ax.set_title("Repeat Status by DNA Motif")
ax.set_xlabel("DNA Repeat Motif")
ax.set_ylabel("Number of Genomic Loci")
ax.tick_params(axis="x", rotation=0)

plt.legend(title="Status")
plt.tight_layout()

plt.savefig(
    RESULTS_DIR / "repeat_status_comparison.png",
    dpi=300
)
plt.show()

print("\nSaved:")
print("results/repeat_status_analysis.csv")
print("results/repeat_status_comparison.png")
