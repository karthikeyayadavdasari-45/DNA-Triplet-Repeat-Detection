
from pathlib import Path
import pandas as pd

# Folder containing the downloaded dataset files
data_dir = Path("data")

# Three motif summary files
files = [
    "CAG_Platinum_by_locus.csv",
    "CGG_Platinum_by_locus.csv",
    "GAA_Platinum_by_locus.csv",
]

for filename in files:
    path = data_dir / filename

    print("\n" + "=" * 70)
    print(f"FILE: {filename}")
    print("=" * 70)

    if not path.exists():
        print(f"ERROR: File not found: {path}")
        continue

    try:
        # These files are tab-separated
        df = pd.read_csv(path, sep="\t")

        print(f"Rows: {len(df)}")
        print(f"Columns: {len(df.columns)}")

        print("\nColumn names:")
        print(df.columns.tolist())

        print("\nFirst 5 rows:")
        print(df.head().to_string(index=False))

        print("\nMissing values in each column:")
        print(df.isnull().sum().to_string())

    except Exception as error:
        print(f"ERROR reading {filename}: {error}")

print("\nInspection completed.")
