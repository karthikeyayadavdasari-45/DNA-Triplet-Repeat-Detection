
from pathlib import Path
import pandas as pd

data_dir = Path(__file__).resolve().parent / "data"

files = {
    "CAG": "Repeats_CAG_Platinum_filtered.csv",
    "CGG": "Repeats_CGG_Platinum_filtered.csv",
    "GAA": "Repeats_GAA_Platinum_filtered.csv",
}

for motif, filename in files.items():
    df = pd.read_csv(
        data_dir / filename,
        sep="\t",
        dtype={"Call_ID": str, "GT": str},
        low_memory=False
    )

    zero_rows = df[df["Allele2_Units"] == 0]

    print("\n" + "=" * 45)
    print(f"{motif} — ZERO ALLELE2 INSPECTION")
    print("Rows with Allele2_Units = 0:", len(zero_rows))
    print("\nGenotype counts:")
    print(zero_rows["GT"].value_counts(dropna=False).to_string())

    print("\nFirst 5 matching records:")
    print(
        zero_rows[
            ["Call_ID", "Sample_ID", "GT",
             "Allele1_Units", "Allele2_Units"]
        ].head().to_string(index=False)
    )

print("\nInspection completed. No source data was changed.")
