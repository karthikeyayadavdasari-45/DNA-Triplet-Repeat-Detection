
from pathlib import Path
import pandas as pd

DATA_DIR = Path("data")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

motifs = {
    "CAG": "CAG_Platinum_by_locus.csv",
    "CGG": "CGG_Platinum_by_locus.csv",
    "GAA": "GAA_Platinum_by_locus.csv",
}

summary_rows = []
combined_rows = []

for motif, filename in motifs.items():
    path = DATA_DIR / filename
    df = pd.read_csv(path, sep="\t")

    # Convert measurement columns to numeric values
    numeric_columns = [
        "Ref_Units", "Mean_Units", "Med_Units",
        "Min_Units", "Max_Units", "Hits",
        "Instability_Rating", "SD"
    ]

    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    summary = {
        "Motif": motif,
        "Loci": len(df),
        "Mean_Repeat_Units": df["Mean_Units"].mean(),
        "Median_Repeat_Units": df["Med_Units"].median(),
        "Minimum_Repeat_Units": df["Min_Units"].min(),
        "Maximum_Repeat_Units": df["Max_Units"].max(),
        "Stable_Loci": (df["Status"] == "STABLE").sum(),
        "Polymorphic_Loci": (df["Status"] == "POLYMORPHIC").sum(),
        "Missing_SD": int(df["SD"].isna().sum()),
        "Missing_Values_Total": int(df.isna().sum().sum()),
    }

    summary_rows.append(summary)

    df.insert(0, "Motif", motif)
    combined_rows.append(df)

    print(f"\n{'=' * 55}")
    print(f"{motif} SUMMARY")
    print(f"{'=' * 55}")

    for key, value in summary.items():
        print(f"{key}: {value}")

# Save summary statistics
summary_df = pd.DataFrame(summary_rows)
summary_path = RESULTS_DIR / "locus_analysis_summary.csv"
summary_df.to_csv(summary_path, index=False)

# Save all locus-level records in one file
combined_df = pd.concat(combined_rows, ignore_index=True)
combined_path = RESULTS_DIR / "combined_locus_data.csv"
combined_df.to_csv(combined_path, index=False)

print("\nAnalysis completed.")
print(f"Summary saved to: {summary_path}")
print(f"Combined data saved to: {combined_path}")
print("\nSummary table:")
print(summary_df.to_string(index=False))
