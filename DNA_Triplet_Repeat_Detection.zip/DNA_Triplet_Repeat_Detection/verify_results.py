
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

for motif in ["CAG", "CGG", "GAA"]:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    print(f"\n{'=' * 55}")
    print(f"{motif} DATA VERIFICATION")
    print(f"{'=' * 55}")

    print("Rows:", len(df))
    print("Unique samples:", df["Sample_ID"].nunique())
    print("Unique genomic loci:",
          df[["Chr", "Start", "End"]].drop_duplicates().shape[0])

    for col in ["Ref_Units", "Allele1_Units", "Allele2_Units"]:
        values = pd.to_numeric(df[col], errors="coerce")

        print(f"\n{col}")
        print("Invalid or missing:", int(values.isna().sum()))
        print("Zero values:", int(values.eq(0).sum()))
        print("Minimum:", values.min())
        print("Median:", values.median())
        print("Maximum:", values.max())

    print("\nDuplicate sample-locus rows:",
          int(df.duplicated(
              subset=["Sample_ID", "Chr", "Start", "End"]
          ).sum()))
