
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(exist_ok=True)

motifs = ["CAG", "CGG", "GAA"]
summaries = []

for motif in motifs:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    for col in ["Ref_Units", "Allele1_Units", "Allele2_Units"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    alleles = pd.concat(
        [df["Allele1_Units"], df["Allele2_Units"]],
        ignore_index=True
    ).dropna()

    summaries.append({
        "Motif": motif,
        "Records": len(df),
        "Unique_Samples": df["Sample_ID"].nunique(),
        "Unique_Loci": df[["Chr", "Start", "End"]].drop_duplicates().shape[0],
        "Mean_Allele_Units": alleles.mean(),
        "Median_Allele_Units": alleles.median(),
        "Maximum_Allele_Units": alleles.max()
    })

summary_df = pd.DataFrame(summaries)
summary_df.to_csv(RESULTS_DIR / "final_motif_comparison.csv", index=False)

# Chart 1: Record counts
plt.figure(figsize=(8, 5))
plt.bar(summary_df["Motif"], summary_df["Records"])
plt.title("Records by Repeat Motif")
plt.xlabel("Repeat motif")
plt.ylabel("Number of records")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "comparison_record_counts.png", dpi=200)
plt.close()

# Chart 2: Mean repeat units
plt.figure(figsize=(8, 5))
plt.bar(summary_df["Motif"], summary_df["Mean_Allele_Units"])
plt.title("Mean Allele Repeat Units by Motif")
plt.xlabel("Repeat motif")
plt.ylabel("Mean repeat units")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "comparison_mean_repeat_units.png", dpi=200)
plt.close()

# Chart 3: Maximum observed allele repeat units
plt.figure(figsize=(8, 5))
plt.bar(summary_df["Motif"], summary_df["Maximum_Allele_Units"])
plt.title("Maximum Observed Allele Repeat Units")
plt.xlabel("Repeat motif")
plt.ylabel("Maximum repeat units")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "comparison_max_repeat_units.png", dpi=200)
plt.close()

print("\nComparison completed.")
print(summary_df.round(3).to_string(index=False))
print(f"\nReports and graphs saved to: {RESULTS_DIR}")
