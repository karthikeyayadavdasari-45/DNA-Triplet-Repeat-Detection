
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

for motif in ["CAG", "CGG", "GAA"]:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    # A locus is identified by its genomic coordinates.
    locus_cols = ["Chr", "Start", "End"]

    print(f"\n{'=' * 45}")
    print(f"{motif} LOCUS INSPECTION")
    print(f"{'=' * 45}")

    # IDs repeated across different samples may be legitimate.
    print(
        "Unique Call_ID values:",
        df["Call_ID"].nunique()
    )

    print(
        "Call_ID values appearing in multiple samples:",
        int(
            (df.groupby("Call_ID")["Sample_ID"].nunique() > 1).sum()
        )
    )

    # Check whether the same locus occurs more than once
    # within an individual sample.
    duplicate_mask = df.duplicated(
        subset=["Sample_ID"] + locus_cols,
        keep=False
    )

    print(
        "Rows at repeated loci within the same sample:",
        int(duplicate_mask.sum())
    )

    print(
        "Unique genomic loci:",
        df[locus_cols].drop_duplicates().shape[0]
    )

    if duplicate_mask.any():
        print("\nExample repeated loci:")
        print(
            df.loc[
                duplicate_mask,
                ["Sample_ID", "Call_ID"] + locus_cols
            ].head(10).to_string(index=False)
        )
