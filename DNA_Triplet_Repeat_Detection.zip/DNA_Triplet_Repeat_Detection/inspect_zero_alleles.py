
import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent / "data"

for motif in ["CAG", "CGG", "GAA"]:
    path = DATA_DIR / f"Repeats_{motif}_Platinum_filtered.csv"
    df = pd.read_csv(path, sep="\t", dtype=str)

    zero = df["Allele2_Units"].str.strip().eq("0")

    print(f"\n{'=' * 50}")
    print(f"{motif} GENOTYPE CHECK")
    print("=" * 50)

    print("\nGT values in zero-allele rows:")
    print(df.loc[zero, "GT"].value_counts(dropna=False).to_string())

    print("\nGT values in nonzero-allele rows:")
    print(
        df.loc[~zero, "GT"]
        .value_counts(dropna=False)
        .head(15)
        .to_string()
    )

    print("\nExample rows:")
    cols = [
        "Sample_ID", "Call_ID", "GT",
        "Ref_Units", "Allele1_Units", "Allele2_Units"
    ]
    print(df.loc[zero, cols].head(5).to_string(index=False))

print("\nGenotype check completed. Original datasets unchanged.")
